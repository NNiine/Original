﻿using System;

namespace uri_1037
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write
        }
    }
}
