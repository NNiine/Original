﻿using System;

namespace Curso - pt 3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1 = 1;
            int n2 = 2;

            if (n1 > n2) { Console.WriteLine("N1 é maior que N2"); }
            else { Console.WriteLine("N1 é menor ou igual a N2"); }
        }
    }
}