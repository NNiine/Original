﻿namespace Cursp - pt 1
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("hello World");
        }
    }
}