﻿using System;

class URI
{

    static void Main(string[] args)
    {

        /**
         * Escreva a sua solução aqui
         * Code your solution here
         * Escriba su solución aquí
         */

        int one = int.Parse(Console.ReadLine());
        int two = int.Parse(Console.ReadLine());

        double PROD = one * two;

        Console.WriteLine("PROD = " + PROD);

    }

}