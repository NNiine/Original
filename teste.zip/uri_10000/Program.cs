﻿using System; 

class URI {

    static void Main(string[] args) { 

        /**
         * Escreva a sua solução aqui
         * Code your solution here
         * Escriba su solución aquí
         */
         
         int b = int.Parse(Console.ReadLine());
            int a = int.Parse(Console.ReadLine());
            int x = (a + b);

            x = (a + b);

            Console.WriteLine("X = " + x);

    }

}