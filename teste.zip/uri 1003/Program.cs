﻿using System;

class URI
{

    static void Main(string[] args)
    {

        /**
         * Escreva a sua solução aqui
         * Code your solution here
         * Escriba su solución aquí
         */

        int a = int.Parse(Console.ReadLine());
        int b = int.Parse(Console.ReadLine());

        int soma = a + b;

        Console.WriteLine("SOMA = " + soma);



    }

}